## generate_combinations_df(...,always,drop.dupes.within,drop.dupes.across) ----

test_that("cross product outputs", {
  in1 = c("1","2","3")
  in2 = c("4","5")
  
  out_actual = generate_combinations_df(in1,in2)
  
  out_expected = data.frame(
    column2 = c("4","4","4","5","5","5"),
    column1 = c("1","2","3","1","2","3"),
    stringsAsFactors = FALSE
  )
  
  out_expected = dplyr::select(out_expected, dplyr::all_of(colnames(out_actual)))
  
  expect_true(all.equal(out_actual, out_expected))
})

test_that("always appears in all products", {
  in1 = c("1","2")
  in2 = c("3","4")
  in3 = c("5","6")
  
  out_actual = generate_combinations_df(in1,in2, always = in3)
  
  out_expected = data.frame(
    column1 = c("5","5","5","5"),
    column2 = c("6","6","6","6"),
    column3 = c("1","2","1","2"),
    column4 = c("3","3","4","4"),
    stringsAsFactors = FALSE
  )
  
  out_expected = dplyr::select(out_expected, dplyr::all_of(colnames(out_actual)))
  
  expect_true(all.equal(out_actual, out_expected))
})

test_that("NA values produce combinations",{
  in1 = c("a", NA)
  in2 = c("b", NA)
  
  out_actual = generate_combinations_df(in1, in2)
  
  out_expected = data.frame(
    column1 = c("a",NA,"a"),
    column2 = c("b","b",NA),
    stringsAsFactors = FALSE
  )
  
  out_expected = dplyr::select(out_expected, dplyr::all_of(colnames(out_actual)))
  
  expect_true(all.equal(out_actual, out_expected))
})

test_that("product removes dupes within", {
  in1 = c("a","b")
  in2 = c("a","c")
  
  out_dupes = generate_combinations_df(in1, in2, drop.dupes.within = FALSE)
  out_no_dupes = generate_combinations_df(in1, in2, drop.dupes.within = TRUE)
  
  expected_no_dupes = data.frame(
    column1 = c("a","b","a","b"),
    column2 = c( NA,"a","c","c"),
    stringsAsFactors = FALSE
  )
  
  expected_no_dupes = dplyr::select(expected_no_dupes, dplyr::all_of(colnames(out_no_dupes)))
  
  expect_true(all.equal(out_no_dupes, expected_no_dupes))
  
  expect_false(identical(out_dupes, out_no_dupes))
})

test_that("product removes dupes across", {
  in1 = c("a","b")
  
  out_dupes = generate_combinations_df(in1, in1, drop.dupes.across = FALSE, drop.dupes.within = FALSE)
  out_no_dupes = generate_combinations_df(in1, in1, drop.dupes.across = TRUE, drop.dupes.within = FALSE)
  
  expected_no_dupes = data.frame(
    column1 = c("a","b","b"),
    column2 = c("a","a","b"),
    stringsAsFactors = FALSE
  )
  
  expected_no_dupes = dplyr::select(expected_no_dupes, dplyr::all_of(colnames(out_no_dupes)))
  
  expect_true(all.equal(out_no_dupes, expected_no_dupes))
  
  expect_false(identical(out_dupes, out_no_dupes))
})

## cross_product_column_names(...,always,drop.dupes.within,drop.dupes.across) ----

test_that("cross product outputs", {
  in1 = c("1","2","3")
  in2 = c("4","5")
  out_manual = list(c("1","4"),c("1","5"),c("2","4"),c("2","5"),c("3","4"),c("3","5"))
  out1 = cross_product_column_names(in1,in2)
  out2 = cross_product_column_names(in2,in1)
  out2 = lapply(out2, sort)
  
  expect_setequal(out1, out_manual)
  expect_setequal(out2, out_manual)
})

test_that("always appears in all products", {
  in1 = c("1","2","3")
  in2 = c("4","5")
  in3 = c("6")
  
  out_manual = list(c("1","4","6"),c("1","5","6"),c("2","4","6"),c("2","5","6"),c("3","4","6"),c("3","5","6"))
  out1 = cross_product_column_names(in1,in2, in3)
  out2 = cross_product_column_names(in1,in2, always = in3)
  out1 = lapply(out1, sort)
  out2 = lapply(out2, sort)
  
  expect_setequal(out1, out_manual)
  expect_setequal(out2, out_manual)
  
  out_always = list(c("1","4","5"),c("2","4","5"),c("3","4","5"))
  out1 = cross_product_column_names(in1, always = in2)
  out2 = cross_product_column_names(always = in2, in1)
  out1 = lapply(out1, sort)
  out2 = lapply(out2, sort)
  
  expect_setequal(out1, out_always)
  expect_setequal(out2, out_always)
})

test_that("NA values produce combinations",{
  in1 = c("a", NA)
  in2 = c("b", NA)
  
  expected_out = list("a","b",c("a","b"))
  actual_out = cross_product_column_names(in1, in2)
  
  expect_setequal(expected_out, actual_out)
})

test_that("product removes dupes within", {
  in1 = c("a","b")
  in2 = c("a","c")
  out_dupes_manual = list(c("a","a"),c("a","b"),c("a","c"),c("b","c"))
  out_no_dupes_manual = list(c("a"),c("a","b"),c("a","c"),c("b","c"))
  
  out_dupes = cross_product_column_names(in1, in2, drop.dupes.within = FALSE)
  out_no_dupes = cross_product_column_names(in1, in2, drop.dupes.within = TRUE)
  out_dupes = lapply(out_dupes, sort)
  out_no_dupes = lapply(out_no_dupes, sort)
  
  expect_setequal(out_dupes, out_dupes_manual)
  expect_setequal(out_no_dupes, out_no_dupes_manual)
})

test_that("product removes dupes across", {
  in1 = c("a","b")
  out_dupes_manual = list(c("a","a"),c("a","b"),c("b","a"),c("b","b"))
  out_no_dupes_within_manual = list(c("a"),c("a","b"),c("b","a"),c("b"))
  out_no_dupes_across_manual = list(c("a","a"),c("b","a"),c("b","b"))
  out_no_dupes_both_manual = list(c("a"),c("b","a"),c("b"))
  
  out_dupes = cross_product_column_names(in1, in1, drop.dupes.within = FALSE, drop.dupes.across = FALSE)
  out_no_dupes_within = cross_product_column_names(in1, in1, drop.dupes.within = TRUE, drop.dupes.across = FALSE)
  out_no_dupes_across = cross_product_column_names(in1, in1, drop.dupes.within = FALSE, drop.dupes.across = TRUE)
  out_no_dupes_both = cross_product_column_names(in1, in1, drop.dupes.within = TRUE, drop.dupes.across = TRUE)
  
  expect_setequal(out_dupes, out_dupes_manual)
  expect_setequal(out_no_dupes_within, out_no_dupes_within_manual)
  expect_setequal(out_no_dupes_across, out_no_dupes_across_manual)
  expect_setequal(out_no_dupes_both, out_no_dupes_both_manual)
})

## expand_compact_summary_groups(compact_control_file,column_names,drop.dupes.within,drop.dupes.across) ----

test_that("basic | expands", {
  input = data.frame(
    group.1 = c("a|b","c|d"),
    GROUP02 = c("x","y|z")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group.1 = c("a","b","c","c","d","d"),
    GROUP02 = c("x","x","y","z","y","z")
  )
  
  expect_true(all.equal(actual, expected))
})

test_that("|+ expands to NAs", {
  input = data.frame(
    group.1 = c("a|+","c"),
    GROUP02 = c("x","y  |   +    ")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group.1 = c("a",NA,"c","c"),
    GROUP02 = c("x","x","y",NA)
  )
  
  expect_true(all.equal(actual, expected))
})

test_that("prefix and suffix expand", {
  input = data.frame(
    group.1 = c("*_x|+","y_*"),
    GROUP02 = c("a","b")
  )
  
  column_names = c("1_x", "2_x", "y_3", "y_4")
  actual = expand_compact_summary_groups(input, column_names)
  
  expected = data.frame(
    group.1 = c("1_x", "2_x", NA, "y_3", "y_4"),
    GROUP02 = c("a","a","a","b","b")
  )
  
  expect_true(all.equal(actual, expected))
  
  # reverse order
  input = data.frame(
    group.1 = c("y_*", "*_x|+"),
    GROUP02 = c("b","a")
  )
  
  column_names = c("1_x", "2_x", "y_3","y_4")
  actual = expand_compact_summary_groups(input, column_names)
  
  expected = data.frame(
    group.1 = c("y_3","y_4","1_x", "2_x", NA),
    GROUP02 = c("b","b","a","a","a")
  )
  
  expect_true(all.equal(actual, expected))
})

test_that("prefix or suffix performs", {
  input = data.frame(group = c("*_x | y_*"))
  
  column_names = c("1_x", "2_x", "y_3", "y_4")
  actual = expand_compact_summary_groups(input, column_names)
  
  expected = data.frame(group = c("1_x", "2_x", "y_3", "y_4"))
  
  expect_true(all.equal(actual, expected))
  
  # reverse order
  input = data.frame(group = c("y_* | *_x"))
  
  column_names = c("1_x", "2_x", "y_3","y_4")
  actual = expand_compact_summary_groups(input, column_names)
  
  expected = data.frame(group = c("y_3","y_4","1_x", "2_x"))
  
  expect_true(all.equal(actual, expected))
})

test_that("prefix and suffix without underscore does not expand", {
  input = data.frame(
    group.1 = c("*x","y*"),
    GROUP02 = c("a","b")
  )
  
  column_names = c("1_x", "2_x", "y_y")
  actual = expand_compact_summary_groups(input, column_names)

  expect_true(all.equal(actual, input))
})

test_that("missing prefix or suffix errors", {
  input = data.frame(
    group.1 = c("*_x|+","y_*"),
    GROUP02 = c("a","b")
  )
  
  column_names = c("1x", "2x", "y_y")
  expect_error(expand_compact_summary_groups(input, column_names), "suffix")
  column_names = c("1_x", "2_x", "yy")
  expect_error(expand_compact_summary_groups(input, column_names), "prefix")
})

test_that("drop.within performs", {
  input = data.frame(
    group1 = c("a","b","c","d"),
    group2 = c("a","c","d","e"),
    group3 = c("a","b","d","f"),
    group4 = c("a","b","c","f")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group1 = c("a","b","c","d"),
    group2 = c( NA,"c","d","e"),
    group3 = c( NA, NA, NA,"f"),
    group4 = c( NA, NA, NA, NA_character_)
  )
  
  expect_true(all.equal(actual, expected))
  
  actual = expand_compact_summary_groups(input, drop.dupes.within = FALSE)
  expect_true(all.equal(actual, input))
})

test_that("drop.across performs", {
  input = data.frame(
    group1 = c("a","c","c","d","c","d"),
    group2 = c("b","d","d", NA,"d", NA),
    group3 = c("c","b", NA, NA, NA, NA),
    group4 = c("d","a", NA,"c", NA,"c"),
    count1 = c("z","z","z","z","y","y")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group1 = c("a","c","c"),
    group2 = c("b","d","d"),
    group3 = c("c", NA, NA),
    group4 = c("d", NA, NA),
    count1 = c("z","z","y")
  )
  
  expect_true(all.equal(actual, expected))
  
  actual = expand_compact_summary_groups(input, drop.dupes.across = FALSE)
  expect_true(all.equal(actual, input))
})

test_that("empty rows removed", {
  input = data.frame(
    group1 = c("a", NA),
    group2 = c("b", NA),
    count1 = c( NA,"x")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group1 = c("a"),
    group2 = c("b"),
    count1 = c(NA_character_)
  )
  
  expect_true(all.equal(actual, expected))
  
  # using |+
  input = data.frame(
    group1 = c("a|+"),
    group2 = c("b|+")
  )
  
  actual = expand_compact_summary_groups(input)
  
  expected = data.frame(
    group1 = c("a","a", NA),
    group2 = c("b", NA,"b")
  )
  
  expect_true(all.equal(actual, expected))
})

test_that("white space is removed", {
  input = data.frame(
    group.1 = c(" *_x | +"," y_* "),
    GROUP02 = c("a","b")
  )
  
  column_names = c("1_x", "2_x", "y_3", "y_4")
  actual = expand_compact_summary_groups(input, column_names)
  
  expected = data.frame(
    group.1 = c("1_x", "2_x", NA, "y_3", "y_4"),
    GROUP02 = c("a","a","a","b","b")
  )
  
  expect_true(all.equal(actual, expected))
})

test_that("combining expansions performs by column", {
  input = data.frame(
    group1 = c(
      "a", "a|b", "a|+", "a|b|+",
      " a ", "a | b", "a | +", "a | b | +",
      "x_*", "x_*|+", "x_*|a", "a|x_*",
      " x_* ", " x_* | +", " x_* | a ", " a | x_* ",
      "*_y", "*_y|+", "*_y|b", "b|*_y",
      " *_y ", "*_y | +", " *_y | b ", " b | *_y ",
      "x_*|*_y", "*_y|x_*", "a|*_y|x_*", "*_y|a|x_*", "x_*|*_y|b",
      " x_* | *_y ", " *_y | x_* ", " a | *_y | x_* ", " *_y | a | x_* ", " x_* | *_y | b "
    ),
    group2 = c(
      rep("n",4),
      rep("s",4),
      rep("n",4),
      rep("s",4),
      rep("n",4),
      rep("s",4),
      rep("n",5),
      rep("s",5)
    )
  )
  
  column_names = c("x_1", "x_2", "3_y", "4_y")
  actual = expand_compact_summary_groups(input, column_names, drop.dupes.across = FALSE)
  
  expected_num_rows = 8 + 8 + 11 + 11 + 11 + 11 + 23 + 23
  
  expect_equal(nrow(actual), expected_num_rows)
})

test_that("combining expansions performs by row", {
  input = data.frame(
    group1 = "a",
    group2 = "b|c",
    group3 = "x_*",
    group4 = "*_y",
    group5 = "d|e|+",
    group6 = NA,
    group7 = "x_* | +",
    group8 = "f | *_y",
    group9 = "x_* | *_y | g | +"
  )
  
  column_names = c("x_1", "x_2", "3_y", "4_y")
  actual = expand_compact_summary_groups(input, column_names, drop.dupes.across = FALSE, drop.dupes.within = FALSE)
  
  expected_num_rows = 1 * 2 * 2 * 2 * 3 * 1 * 3 * 3 * 6
  
  expect_equal(nrow(actual), expected_num_rows)
})

## generate_summary_commands(summary_row) --------------------------------- ----

test_that("individual summary commands run",{
  
  # distinct
  summary_row = data.frame(DISTINCT2 = "col", stringsAsFactors = FALSE)
  expected = c(distinct2 = "dplyr::n_distinct(col, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # count
  summary_row = data.frame(COUNT05 = "col", stringsAsFactors = FALSE)
  expected = c(count05 = "sum(ifelse(!is.na(col), 1, 0), na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # sum
  summary_row = data.frame(sum = "col", stringsAsFactors = FALSE)
  expected = c(sum = "sum(col, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # entity
  summary_row = data.frame(ENTITY1 = "col", stringsAsFactors = FALSE)
  expected = c(entity1 = "ifelse(dplyr::n_distinct(col, na.rm = TRUE) == 0, NA, dplyr::n_distinct(col, na.rm = TRUE))")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # stddev
  summary_row = data.frame(STDDEV3 = "col", stringsAsFactors = FALSE)
  expected = c(stddev3 = "sd(col, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # max
  summary_row = data.frame(MAX.1 = "col", stringsAsFactors = FALSE)
  expected = c(max.1 = "max(col, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # min
  summary_row = data.frame(min02 = "col", stringsAsFactors = FALSE)
  expected = c(min02 = "min(col, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
  # seed
  summary_row = data.frame(SEED.1 = "col", stringsAsFactors = FALSE)
  expected = c(seed.1 = "sum(col %% 100, na.rm = TRUE)")
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
  
})

test_that("multiple summary commands run",{
  
  summary_row = data.frame(
    DISTINCT1 = "col1",
    DISTINCT2 = "col2",
    COUNT05 = "col3",
    SEED = "col1",
    stringsAsFactors = FALSE
  )
  expected = c(
    distinct1 = "dplyr::n_distinct(col1, na.rm = TRUE)",
    distinct2 = "dplyr::n_distinct(col2, na.rm = TRUE)",
    count05 = "sum(ifelse(!is.na(col3), 1, 0), na.rm = TRUE)",
    seed = "sum(col1 %% 100, na.rm = TRUE)"
  )
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
})

test_that("NAs skipped",{
  
  summary_row = data.frame(
    DISTINCT1 = "col1",
    DISTINCT2 = NA,
    COUNT05 = "col3",
    SEED = NA,
    stringsAsFactors = FALSE
  )
  expected = c(
    distinct1 = "dplyr::n_distinct(col1, na.rm = TRUE)",
    count05 = "sum(ifelse(!is.na(col3), 1, 0), na.rm = TRUE)"
  )
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
})

test_that("additional columns ignored",{
  
  summary_row = data.frame(
    DISTINCT1 = "col1",
    random_col_name = "col2",
    COUNT05 = "col3",
    stringsAsFactors = FALSE
  )
  expected = c(
    distinct1 = "dplyr::n_distinct(col1, na.rm = TRUE)",
    count05 = "sum(ifelse(!is.na(col3), 1, 0), na.rm = TRUE)"
  )
  
  actual = generate_summary_commands(summary_row)
  expect_equal(actual, expected)
})

## entity_union_all_conversion(summary_row, tbl) -------------------------- ----

test_that("No entities returns unchanged", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "uid",
    entity = NA_character_,
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    ent = c(100,200,100,200,300,200),
    stringsAsFactors = FALSE
  )
  
  actual = entity_union_all_conversion(summary_row, tbl)
  
  expect_identical(actual, tbl)
})

test_that("Existing entities returns unchanged", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "uid",
    entity = "ent",
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    ent = c(100,200,100,200,300,200),
    stringsAsFactors = FALSE
  )
  
  actual = entity_union_all_conversion(summary_row, tbl)
  
  expect_identical(actual, tbl)
})

test_that("Unaccepted reuse errors", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "region",
    entity = "ent",
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    ent__min = c(100,200,100,200,300,200),
    stringsAsFactors = FALSE
  )
  
  expect_error(entity_union_all_conversion(summary_row, tbl), "group and summary")
})

test_that("Min and max doubled", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "uid",
    entity = "ent",
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    age = c(20,30,40,50,60,70),
    ent__min = c(100,200,100,200,300,200),
    ent__max = c(700,800,800,700,800,900),
    stringsAsFactors = FALSE
  )
  
  expected = data.frame(
    region = rep(c(1,2,3,1,2,3), 2),
    area = rep(c(9,9,9,8,8,8), 2),
    uid = c(111,222,333,444,555,666,rep(NA,6)),
    age = c(20,30,40,50,60,70,rep(NA,6)),
    ent__min = c(100,200,100,200,300,200,rep(NA,6)),
    ent__max = c(700,800,800,700,800,900,rep(NA,6)),
    ent = c(100,200,100,200,300,200,700,800,800,700,800,900),
    stringsAsFactors = FALSE
  )
  
  actual = entity_union_all_conversion(summary_row, tbl)
  
  expect_identical(actual, expected)
})

test_that("only min works", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "uid",
    entity = "ent",
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    age = c(20,30,40,50,60,70),
    ent__min = c(100,200,100,200,300,200),
    stringsAsFactors = FALSE
  )
  
  expected = data.frame(
    region = rep(c(1,2,3,1,2,3), 2),
    area = rep(c(9,9,9,8,8,8), 2),
    uid = c(111,222,333,444,555,666,rep(NA,6)),
    age = c(20,30,40,50,60,70,rep(NA,6)),
    ent__min = c(100,200,100,200,300,200,rep(NA,6)),
    ent = c(100,200,100,200,300,200,rep(NA,6)),
    stringsAsFactors = FALSE
  )
  
  actual = entity_union_all_conversion(summary_row, tbl)
  
  expect_identical(actual, expected)
})

test_that("only max works", {
  summary_row = data.frame(
    group = "region",
    group2 = "area",
    count = "uid",
    entity = "ent",
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    region = c(1,2,3,1,2,3),
    area = c(9,9,9,8,8,8),
    uid = c(111,222,333,444,555,666),
    age = c(20,30,40,50,60,70),
    ent__max = c(700,800,800,700,800,900),
    stringsAsFactors = FALSE
  )
  
  expected = data.frame(
    region = rep(c(1,2,3,1,2,3), 2),
    area = rep(c(9,9,9,8,8,8), 2),
    uid = c(111,222,333,444,555,666,rep(NA,6)),
    age = c(20,30,40,50,60,70,rep(NA,6)),
    ent__max = c(700,800,800,700,800,900,rep(NA,6)),
    ent = c(rep(NA,6),700,800,800,700,800,900),
    stringsAsFactors = FALSE
  )
  
  actual = entity_union_all_conversion(summary_row, tbl)
  
  expect_identical(actual, expected)
})

## tolower_control_file_cells(summary_control_file, tbl_cols) ------------- ----

test_that("capitalisation_changed", {
  cf = data.frame(
    GROUP = c("aa","bb","cc","dd"),
    GROUP2 = c("AA","BB","CC","DD")
  )
  
  actual = tolower_control_file_cells(cf, c("GROUP", "GROUP2"))
  
  expected = data.frame(
    GROUP = c("aa","bb","cc","dd"),
    GROUP2 = c("aa","bb","cc","dd")
  )
  
  expect_equal(actual, expected)
})

test_that("Within dynamics changed", {
  cf = data.frame(
    WHERE = c("{ COL = 'string' }", "{ Col1 == Val1 }")
  )
  
  actual = tolower_control_file_cells(cf, c("COL", "Col1", "Val1"))
  
  expected = data.frame(
    WHERE = c("{ col = 'string' }", "{ col1 == val1 }")
  )
  
  expect_equal(actual, expected)
})

test_that("whole words preserved", {
  cf = data.frame(
    SUM = c("{ COL = 'STRING' }", "{ rinG == COLUMN }")
  )
  
  actual = tolower_control_file_cells(cf, c("COL", "ring"))
  
  expected = data.frame(
    SUM = c("{ col = 'STRING' }", "{ ring == COLUMN }")
  )
  
  expect_equal(actual, expected)
  
})

test_that("out of scope cols unchanged", {
  cf = data.frame(
    GROUP = c("aa","bb","cc","dd"),
    FILE = c("AA","BB","CC","DD")
  )
  
  actual = tolower_control_file_cells(cf, c("GROUP", "GROUP2"))
  
  expect_equal(actual, cf)
})

## remove_empty_entity_columns(summary_control_file, tbl) ----------------- ----

test_that("no entities passes unchanged", {
  cf = data.frame(
    group1 = c("col1", "col2"),
    count1 = c("col3", NA),
    sum1 = c(NA, "col3"),
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    col1 = c(1:5,1:5),
    col2 = rep(c("a","b"), 5),
    col3 = c(11:20),
    stringsAsFactors = FALSE
  )
  
  actual = remove_empty_entity_columns(cf, tbl)
  
  expect_equal(actual, cf)
})

test_that("populated entities passes unchanged", {
  cf = data.frame(
    group1 = c("col1", "col2"),
    entity1 = c("ent1", "ent2"),
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    col1 = c(1:5,1:5),
    col2 = rep(c("a","b"), 5),
    ent1 = c(NA, 1:3, NA, 1:3, NA, NA),
    ent2__min = c(rep(NA, 9), 111),
    ent2__max = c(rep(NA, 9), 222),
    stringsAsFactors = FALSE
  )
  
  actual = remove_empty_entity_columns(cf, tbl)
  
  expect_equal(actual, cf)
})

test_that("zero entities removed", {
  cf = data.frame(
    group1 = c("col1", "col2"),
    entity1 = c("ent1", "ent2"),
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    col1 = c(1:5,1:5),
    col2 = rep(c("a","b"), 5),
    ent1 = NA_character_,
    ent2__min = NA_character_,
    ent2__max = NA_character_,
    stringsAsFactors = FALSE
  )
  
  actual = remove_empty_entity_columns(cf, tbl)
  
  expected = data.frame(
    group1 = c("col1", "col2"),
    entity1 = c(NA_character_, NA_character_),
    stringsAsFactors = FALSE
  )
  
  expect_equal(actual, expected)
})

test_that("mixed entities handled as expected", {
  cf = data.frame(
    group1 = c("col1", "col2"),
    entity1 = c("ent1", "ent2"),
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    col1 = c(1:5,1:5),
    col2 = rep(c("a","b"), 5),
    ent1 = NA_character_,
    ent2__min = c(rep(NA, 9), 111),
    ent2__max = c(rep(NA, 9), 222),
    stringsAsFactors = FALSE
  )
  
  actual = remove_empty_entity_columns(cf, tbl)
  
  expected = data.frame(
    group1 = c("col1", "col2"),
    entity1 = c(NA_character_, "ent2"),
    stringsAsFactors = FALSE
  )
  
  expect_equal(actual, expected)
})

test_that("dynamic entities left unchanged", {
  cf = data.frame(
    group1 = c("col1", "col2", "col1", "col2"),
    entity1 = c("{ent1}", "{ent2}", "ent1", "ent2"),
    stringsAsFactors = FALSE
  )
  tbl = data.frame(
    col1 = c(1:5,1:5),
    col2 = rep(c("a","b"), 5),
    ent1 = NA_character_,
    ent2__min = c(rep(NA, 9), 111),
    ent2__max = c(rep(NA, 9), 222),
    stringsAsFactors = FALSE
  )
  
  actual = remove_empty_entity_columns(cf, tbl)
  
  expected = data.frame(
    group1 = c("col1", "col2", "col1", "col2"),
    entity1 = c("{ent1}", "{ent2}", NA, "ent2"),
    stringsAsFactors = FALSE
  )
  
  expect_equal(actual, expected)
})
